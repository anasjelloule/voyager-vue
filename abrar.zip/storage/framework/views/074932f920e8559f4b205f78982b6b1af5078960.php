<div class="menu_footer list-group list-group-flush list-group-transparent">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="list-group-item list-group-item-action" href="<?php echo e($item->url); ?>"><?php echo e($item->title); ?></a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>