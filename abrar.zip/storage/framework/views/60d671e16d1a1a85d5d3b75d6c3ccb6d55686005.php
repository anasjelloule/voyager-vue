 
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('partials.head1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<div class="gradient-overlay-half-dark-v3 bg-img-hero" style="background-image: url('img/bg_blog.jpg');">
    <div class="container space-2 space-4-top--lg space-3-bottom--lg">
        <div class="w-lg-100 text-center mx-lg-auto">
            <h1 class="display-2 font-size-48--md-down text-primary mb-0">Actualités</h1>
        </div>
    </div>
</div>
<div class="container space-2 space-3--lg">
    <div class="row">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card" style="">
                <a href="<?php echo e(route('single',$post->slug)); ?>"><img class="card-img-top" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->title); ?>"> </a>
                <div class="card-body">
                    <h5 class="card-title"><a href="<?php echo e(route('single',$post->slug)); ?>"><?php echo e($post->title); ?></a></h5>
                    <p class="card-text">
                        <?php echo e(str_limit($post->excerpt,100,'...')); ?></p>
                    <a href="<?php echo e(route('single',$post->slug)); ?>" class="btn btn-primary btn-sm">Lire La Suite </a>
                </div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="paginate col-md-12"> <?php echo e($posts->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('style'); ?>
<style>
    .paginate .pagination {
        justify-content: center;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>