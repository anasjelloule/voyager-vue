 
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('partials.head1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?> <?php echo $page_home[0]->body; ?>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('sliders'); ?>
<div id="homeslider" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li data-target="#homeslider" data-slide-to="<?php echo e($loop->index); ?>" class="<?php if($loop->first): ?>
                        active
                    <?php endif; ?> "></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ol>
    <div class="carousel-inner">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item <?php if($loop->first): ?>
                        active
                    <?php endif; ?> ">
            <img class="d-block w-100" src="<?php echo e(asset('storage/'.$slider->photo)); ?>" alt="First slide"> <?php echo $slider->col; ?>


        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    <a class="carousel-control-prev" href="#homeslider" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
    <a class="carousel-control-next" href="#homeslider" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>