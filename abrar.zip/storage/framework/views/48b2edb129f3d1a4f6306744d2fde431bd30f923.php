<ul class="menu_top navbar-nav u-header__navbar-nav">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="nav-item hs-has-sub-menu u-header__nav-item" data-event="hover" data-animation-in="fadeInUp" data-animation-out="fadeOut">
        <a id="<?php echo e(strtolower(str_replace(' ', '', $item->title))); ?>" class="nav-link u-header__nav-link" href="<?php echo e($item->url); ?>">&nbsp;&nbsp;<?php echo e($item->title); ?>&nbsp;&nbsp; <?php if(count($item->children)!=0): ?><span class="fa fa-angle-down u-header__nav-link-icon"></span><?php endif; ?>
            </a> <?php if(count($item->children)!=0): ?>
        <ul id="<?php echo e(strtolower(str_replace(' ', '', $item->title))); ?>" class="list-inline hs-sub-menu u-header__sub-menu mb-0 animated fadeOut"
            style="min-width: 220px; display: none;" aria-labelledby="<?php echo e(strtolower(str_replace(' ', '', $item->title))); ?>">
            <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="dropdown-item hs-has-sub-menu">
                <a id="<?php echo e(strtolower(str_replace(' ', '', $item_children->title))); ?>" class="nav-link u-header__sub-menu-nav-link" href="<?php echo e($item->url); ?>"
                    aria-haspopup="true" aria-expanded="false" aria-controls="<?php echo e(strtolower(str_replace(' ', '', $item_children->title))); ?>">
                    <?php echo e($item_children->title); ?>

               
                </a>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul><?php endif; ?>
    </li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>