 
<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('partials.head1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('script'); ?>
<script src="js/countUp.min.js"></script>
<script>
  $('.counter').each(function() {
  var $this = $(this),
      countTo = $this.attr('data-count');
  
  $({ countNum: $this.text()}).animate({
    countNum: countTo
  },

  {

    duration: 2500,
    easing:'linear',
    step: function() {
      $this.text(Math.floor(this.countNum));
    },
    complete: function() {
      $this.text(this.countNum);
      //alert('finished');
    }

  });  
  
  

});

</script>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?> <?php echo $page->body; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>