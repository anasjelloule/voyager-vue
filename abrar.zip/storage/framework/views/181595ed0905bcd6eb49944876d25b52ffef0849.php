<p>

    Hi , <?php echo e($data['name']); ?>

</p>