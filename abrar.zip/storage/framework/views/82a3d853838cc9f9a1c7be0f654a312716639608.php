 
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('partials.head1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<div class="gradient-overlay-half-dark-v3 bg-img-hero" style="background-image: url('<?php echo e(asset('storage/'.$post->image)); ?>');">
    <div class="container space-2 space-4-top--lg space-3-bottom--lg">
        <div class="w-lg-100 text-center mx-lg-auto">
            <h1 class="display-2 font-size-48--md-down text-primary mb-0"><?php echo e($post->title); ?></h1>
        </div>
    </div>
</div>
<?php echo $post->body; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>