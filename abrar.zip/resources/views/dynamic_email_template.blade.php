<p>

    Hi , {{$data['name']}}
</p>