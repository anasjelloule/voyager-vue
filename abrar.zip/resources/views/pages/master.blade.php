@include('partials.header')

<!-- ========== MAIN CONTENT ========== -->
<main id="content">
    @yield('sliders') @yield('content')




</main>
<!-- ========== END MAIN CONTENT ========== -->
    @include('partials.footer')